# ExamForge 🎓
**AI-Powered Exam Prep · by Jay Tee (Mahoney Jude Tetteh)**

---

## Deploy in 10 Minutes on Your Phone

### Step 1 — Get your FREE Gemini API Key
1. Open **aistudio.google.com/app/apikey** in your browser
2. Sign in with any Google/Gmail account
3. Tap **"Create API key"**
4. Copy the key (starts with `AIza...`)

---

### Step 2 — Upload to GitHub (free)
1. Go to **github.com** on your phone → create a free account
2. Tap **"New repository"**
3. Name it `examforge` → tap **"Create repository"**
4. Tap **"uploading an existing file"**
5. Upload ALL the files from this folder, keeping the folder structure:
   - `api/generate.js`
   - `public/index.html`
   - `vercel.json`
   - `README.md`
6. Tap **"Commit changes"**

---

### Step 3 — Deploy on Vercel (free)
1. Go to **vercel.com** on your phone → sign up with GitHub
2. Tap **"Add New Project"**
3. Select your `examforge` repository → tap **"Deploy"**
4. Wait ~1 minute → tap **"Continue to Dashboard"**

---

### Step 4 — Add your secret API key
1. In your Vercel dashboard, tap your project
2. Go to **Settings → Environment Variables**
3. Add:
   - **Name:** `GEMINI_API_KEY`
   - **Value:** paste your key from Step 1
4. Tap **"Save"**
5. Go to **Deployments** → tap **"Redeploy"**

---

### Step 5 — Share your link!
Your site is now live at:
`https://examforge.vercel.app` (or similar)

Share that link with students — works on any phone, any browser.

---

## That's it. 100% free. No credit card ever needed.

- **Hosting:** Vercel free tier
- **AI:** Google Gemini free tier (15 requests/minute)
- **Domain:** Free `.vercel.app` domain included

